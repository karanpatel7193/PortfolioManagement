export { AngularMultiSelect } from './lib/multiselect.component';
export { ClickOutsideDirective } from './lib/clickOutside';
export { ListFilterPipe } from './lib/list-filter';
export { Item } from './lib/menu-item';
export { TemplateRenderer } from './lib/menu-item';
export { AngularMultiSelectModule } from './lib/multiselect.component';