export interface WrapGroupDimension {
	childWidth: number;
	childHeight: number;
	items: any[];
}